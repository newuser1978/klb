# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if '404 Error' in data:
        return ResolveError(0)

    sources = scrapertools.find_single_match(data, r'sources: (\[.*?\])')

    for url, label in scrapertools.find_multiple_matches(sources, r'\{file:"([^"]+)"(?:,label:"([^"]+)")?'):
        itemlist.append(Video(url=url, res=label))

    return itemlist
